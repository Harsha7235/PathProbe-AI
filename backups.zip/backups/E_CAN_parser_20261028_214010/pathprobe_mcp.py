﻿import asyncio
import json
from typing import Any

from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client


MCP_SERVER_URL = "http://127.0.0.1:39400/mcp"


async def _call_mcp_tool(tool_name: str) -> dict[str, Any]:
    """Call an approved read-only Packet Tracer MCP tool."""

    allowed_tools = {
        "pt_bridge_status",
        "pt_export_topology",
        "pt_health_check",
    }

    if tool_name not in allowed_tools:
        raise ValueError(f"Tool is not allowed: {tool_name}")

    async with asyncio.timeout(30):
        async with streamable_http_client(
            MCP_SERVER_URL
        ) as (read_stream, write_stream):
            async with ClientSession(
                read_stream, write_stream
            ) as session:
                await session.initialize()

                result = await session.call_tool(
                    tool_name, {}
                )

                if result.is_error:
                    raise RuntimeError(
                        f"MCP tool failed: {tool_name}"
                    )

                text_parts = [
                    item.text
                    for item in result.content
                    if hasattr(item, "text")
                ]

                return {
                    "tool": tool_name,
                    "status": "success",
                    "result": text_parts,
                }


async def get_bridge_status() -> dict[str, Any]:
    return await _call_mcp_tool("pt_bridge_status")


async def export_live_topology() -> dict[str, Any]:
    return await _call_mcp_tool("pt_export_topology")


async def get_live_health_check() -> dict[str, Any]:
    return await _call_mcp_tool("pt_health_check")
