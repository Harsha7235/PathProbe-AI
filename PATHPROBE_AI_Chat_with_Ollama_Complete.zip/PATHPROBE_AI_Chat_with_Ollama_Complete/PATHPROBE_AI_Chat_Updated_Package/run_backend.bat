@echo off
cd /d "%~dp0"
echo Starting PATHPROBE AI backend at http://127.0.0.1:8000
echo Keep this window open while using Packet Tracer.
py -m pip install -r requirements.txt
py -m uvicorn app:app --host 127.0.0.1 --port 8000
pause
