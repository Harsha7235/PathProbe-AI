PATHPROBE AI — Conversational Ollama Update
=============================================

CONTENTS
- ScriptEngine.js: current Script Engine with cached snapshot handshake.
- Interface0.htm: dashboard updated with a conversational chat panel.
- app.py: local FastAPI bridge exposing /api/analyze and /api/chat.
- requirements.txt: Python dependencies.
- run_backend.bat: starts the local bridge on Windows.

WHAT THE CHAT DOES
- Lets you ask Ollama to explain the collected topology, candidate routes, scoring formula, synthetic fault scenarios, unresolved endpoints, and general PATHPROBE project questions.
- Sends current topology summary, source/destination, objective, scenario, candidate paths, and synthetic-metric labels when available.
- Maintains a short chat history during the current page session.
- Does not change Packet Tracer routing or device configuration.

WHY THE SCREEN SHOWED "TypeError: Failed to fetch"
The interface tries to reach http://127.0.0.1:8000/api/analyze. "Failed to fetch" usually means the Python backend is not running/reachable or the browser request was blocked. This package includes the bridge and permissive CORS settings.

SETUP
1. Ensure Ollama is installed and running.
2. Open a terminal and run: ollama list
3. Ensure at least one model is installed. If needed, run (example): ollama pull qwen3
   If your installed model has another name, the backend auto-selects a model from `ollama list`.
   To force a model, set environment variable OLLAMA_MODEL to its exact model name before starting the backend.
4. Install Python 3.10+ if not already installed.
5. Double-click run_backend.bat. Keep the terminal window open.
6. In a browser on the same PC, open http://127.0.0.1:8000/health.
   A response with status "ok" and an available model means the bridge can see Ollama.
7. In Packet Tracer, replace the Script Engine and Interface0.htm with the files in this package.
8. Save and stop/restart the Script Module.
9. Run Find Candidate Paths, then use "Ask Ollama to Select Best Path" or the new "Chat with PATHPROBE AI / Ollama" panel.

IMPORTANT
- Script Engine collection happens once per module start; snapshot handshake retries deliver the cached snapshot and do not rescan.
- The chat can explain the topology even without candidates, but best-path selection requires candidate paths.
- Fault-lab delay, jitter, packet loss, throughput, utilization, reliability, trust, and security values are synthetic scenario values, not live Packet Tracer measurements.
- If endpoint resolution remains partial, path search can be incomplete.
- Syntax validation does not replace testing in your Packet Tracer installation.
