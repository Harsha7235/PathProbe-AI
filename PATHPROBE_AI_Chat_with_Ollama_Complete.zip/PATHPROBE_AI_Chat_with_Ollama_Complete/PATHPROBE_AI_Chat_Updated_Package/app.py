import json
import os
import urllib.request
import urllib.error
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
MODEL_OVERRIDE = os.getenv("OLLAMA_MODEL", "").strip()
REQUEST_TIMEOUT = int(os.getenv("OLLAMA_TIMEOUT_SECONDS", "180"))

app = FastAPI(title="PATHPROBE AI Local Ollama Bridge", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnalyzeRequest(BaseModel):
    task: str = "rank_network_candidate_paths"
    question: str = "Choose and explain the best candidate path."
    candidate_paths: list[dict[str, Any]] = Field(default_factory=list)
    topology: dict[str, Any] = Field(default_factory=dict)
    simulation: dict[str, Any] = Field(default_factory=dict)
    policy: dict[str, Any] = Field(default_factory=dict)

class ChatRequest(BaseModel):
    message: str
    history: list[dict[str, str]] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)

def _http_json(url: str, method: str = "GET", payload: dict | None = None, timeout: int = REQUEST_TIMEOUT):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={"Content-Type": "application/json"} if data is not None else {},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
            return response.status, json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} from {url}: {body[:600]}") from exc
    except Exception as exc:
        raise RuntimeError(f"Could not reach {url}: {exc}") from exc

def available_models() -> list[str]:
    try:
        _, data = _http_json(f"{OLLAMA_BASE_URL}/api/tags", timeout=8)
        return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    except Exception:
        return []

def choose_model() -> str:
    if MODEL_OVERRIDE:
        return MODEL_OVERRIDE
    models = available_models()
    if not models:
        raise RuntimeError(
            "Ollama is not reachable at " + OLLAMA_BASE_URL +
            ". Start Ollama and ensure a model is installed."
        )
    # Prefer models commonly used for local assistant workflows, otherwise use first installed model.
    preferences = ["qwen3:latest", "qwen3", "gemma3:latest", "gemma3", "llama3.2:latest", "llama3.2", "mistral:latest"]
    for pref in preferences:
        for installed in models:
            if installed == pref or installed.split(":")[0] == pref.split(":")[0]:
                return installed
    return models[0]

def ollama_chat(messages: list[dict[str, str]]) -> tuple[str, str]:
    model = choose_model()
    try:
        _, data = _http_json(
            f"{OLLAMA_BASE_URL}/api/chat",
            method="POST",
            payload={
                "model": model,
                "messages": messages,
                "stream": False,
                "options": {"temperature": 0.2},
            },
            timeout=REQUEST_TIMEOUT,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    answer = (data.get("message") or {}).get("content", "").strip()
    if not answer:
        raise HTTPException(status_code=502, detail="Ollama returned an empty response.")
    return answer, model

def compact_context(context: dict[str, Any]) -> dict[str, Any]:
    """Keep prompt size bounded while retaining key topology and candidate evidence."""
    if not context:
        return {}
    out = dict(context)
    topo = out.get("topology")
    if isinstance(topo, dict):
        devices = topo.get("devices", [])
        links = topo.get("links", [])
        out["topology"] = {
            "deviceCount": topo.get("deviceCount", len(devices) if isinstance(devices, list) else None),
            "linkCount": topo.get("linkCount", len(links) if isinstance(links, list) else None),
            "unresolvedEndpointCount": topo.get("unresolvedEndpointCount"),
            "devices_sample": devices[:100] if isinstance(devices, list) else [],
            "links_sample": links[:160] if isinstance(links, list) else [],
            "collectionErrors_sample": (topo.get("collectionErrors") or [])[:15],
            "note": "Topology samples may be truncated for context size; do not assume omitted devices/links do not exist.",
        }
    paths = out.get("candidatePaths")
    if isinstance(paths, list):
        out["candidatePaths"] = paths[:12]
    return out

@app.get("/")
def root():
    return {
        "service": "PATHPROBE AI Local Ollama Bridge",
        "status": "running",
        "endpoints": ["/health", "/api/analyze", "/api/chat"],
    }

@app.get("/health")
def health():
    models = available_models()
    return {
        "status": "ok" if models else "backend_running_ollama_unavailable",
        "backend": "PATHPROBE AI",
        "ollama_url": OLLAMA_BASE_URL,
        "available_models": models,
        "selected_model": MODEL_OVERRIDE or (models[0] if models else None),
    }

@app.post("/api/analyze")
def analyze(request: AnalyzeRequest):
    if not request.candidate_paths:
        raise HTTPException(status_code=400, detail="No candidate paths were supplied. Find candidate paths in PATHPROBE AI first.")
    system = (
        "You are PATHPROBE AI, a careful network path analysis assistant. "
        "Use only the supplied topology, candidate paths, scores, and metric values. "
        "Never invent missing measurements. Metrics marked synthetic are hypothetical scenario values, not real Packet Tracer telemetry. "
        "Do not claim to have changed Packet Tracer routing or device configuration. "
        "Explain the recommended path, identify the candidate rank and local score, compare meaningful alternatives, mention down/unknown/intermittent links, "
        "and state limitations caused by unresolved endpoints or missing metrics. The local numerical score is a heuristic, not a probability."
    )
    user = {
        "question": request.question,
        "task": request.task,
        "candidate_paths": request.candidate_paths[:12],
        "topology_summary": {
            "deviceCount": request.topology.get("deviceCount"),
            "linkCount": request.topology.get("linkCount"),
        },
        "simulation": request.simulation,
        "policy": request.policy,
    }
    answer, model = ollama_chat([
        {"role": "system", "content": system},
        {"role": "user", "content": json.dumps(user, ensure_ascii=False)[:50000]},
    ])
    return {"answer": answer, "model": model}

@app.post("/api/chat")
def chat(request: ChatRequest):
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty.")
    context = compact_context(request.context)
    system = (
        "You are PATHPROBE AI, a conversational network engineering assistant for the user's Cisco Packet Tracer lab. "
        "Answer questions conversationally and explain concepts step by step when asked. Use the attached context when relevant. "
        "Distinguish facts present in the context from assumptions. Candidate paths and local scores come from the PATHPROBE graph-search and heuristic scorer; "
        "do not claim the LLM generated the graph or measured live performance. Fault-lab metrics are synthetic. "
        "If no candidate paths are present, explain that the user should run FIND CANDIDATE PATHS and check endpoint resolution. "
        "Do not claim you modified the Packet Tracer topology, routing, devices, or configuration. "
        "When explaining best path, discuss hop count, down/unknown/intermittent links, local score, and synthetic metrics if present. "
        "If the user asks about a metric absent from the context, say it is unavailable rather than inventing it."
    )
    messages = [{"role": "system", "content": system + "\n\nCURRENT PATHPROBE CONTEXT:\n" + json.dumps(context, ensure_ascii=False)[:55000]}]
    for item in request.history[-10:]:
        role = item.get("role", "")
        content = item.get("content", "")
        if role in ("user", "assistant") and isinstance(content, str) and content.strip():
            messages.append({"role": role, "content": content[:5000]})
    messages.append({"role": "user", "content": request.message[:8000]})
    answer, model = ollama_chat(messages)
    return {"answer": answer, "model": model}
